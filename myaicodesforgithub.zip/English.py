import openai
import gradio

openai.api_key = "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"

messages = [{"role": "system", "content": "You are a English Chatbot that ONLY helps students in their english course and no other subject. Try and give detailed answers and help them improve their writing or reading skills. Help then summarise books from online or help them understand a word, like a dictionary. Help them in any type of writing styles."}]

def CustomChatGPT(user_input):
    messages.append({"role": "user", "content": user_input})
    response = openai.ChatCompletion.create(
        model = "gpt-3.5-turbo",
        messages = messages
    )
    ChatGPT_reply = response["choices"][0]["message"]["content"]
    messages.append({"role": "assistant", "content": ChatGPT_reply})
    return ChatGPT_reply

demo = gradio.Interface(fn=CustomChatGPT, inputs = "text", outputs = "text", title = "English Bot")

demo.launch(share=True)