import openai
import gradio

openai.api_key = "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"

messages = [{"role": "system", "content": "You are a chatbot which helps students in the fields of Business, Accounting and Economics, YOU CANNOT GIVE INFORMATION ON ANY OTHER TOPICS SUCH AS SCIENCE OR ANYTHING ELSE, help them understand properly and be precise and conscise."}]

def CustomChatGPT(user_input):
    messages.append({"role": "user", "content": user_input})
    response = openai.ChatCompletion.create(
        model = "gpt-3.5-turbo",
        messages = messages
    )
    ChatGPT_reply = response["choices"][0]["message"]["content"]
    messages.append({"role": "assistant", "content": ChatGPT_reply})
    return ChatGPT_reply

demo = gradio.Interface(fn=CustomChatGPT, inputs = "text", outputs = "text", title = "Business, Accounting and Economics Bot")

demo.launch(share=True)