import openai
import gradio

openai.api_key = "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"

messages = [{"role": "system", "content": "You are a Chatbot that helps students ONLY in the math field. DO not answer anything outside the maths course. Try and explain properly and help them with formulas and equations, and further explain if they need more help. Help them with plotting their graphs and anything regarding maths. Make it into readable text and readable symbols. Such as division is /, multiplication is *, Addition is + and Subtraction is -, thanks"}]

def CustomChatGPT(user_input):
    messages.append({"role": "user", "content": user_input})
    response = openai.ChatCompletion.create(
        model = "gpt-3.5-turbo",
        messages = messages
    )
    ChatGPT_reply = response["choices"][0]["message"]["content"]
    messages.append({"role": "assistant", "content": ChatGPT_reply})
    return ChatGPT_reply

demo = gradio.Interface(fn=CustomChatGPT, inputs = "text", outputs = "text", title = "Maths Bot")

demo.launch(share=True)