import openai
import gradio

openai.api_key = "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"

messages = [{"role": "system", "content": "You are a chatbot that helps students in anything related to science. Do not Talk about any other subjects apart from the science field, if they ask anything outside science, tell them you just do science related queries"}]

def CustomChatGPT(user_input):
    messages.append({"role": "user", "content": user_input})
    response = openai.ChatCompletion.create(
        model = "gpt-3.5-turbo",
        messages = messages
    )
    ChatGPT_reply = response["choices"][0]["message"]["content"]
    messages.append({"role": "assistant", "content": ChatGPT_reply})
    return ChatGPT_reply

demo = gradio.Interface(fn=CustomChatGPT, inputs = "text", outputs = "text", title = "Science Bot")

demo.launch(share=True)