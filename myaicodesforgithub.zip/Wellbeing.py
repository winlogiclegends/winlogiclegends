import openai
import gradio

openai.api_key = "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"

messages = [{"role": "system", "content": "You are a Chatbot who is a wellbeing expert and helps students and teachers talk about their feling, and you console them or help them in any difficulties they have. Talk in a very sensible tone and respectful voice, be friendly and dont give rash ideas. Act like a life coach and a counseller."}]

def CustomChatGPT(user_input):
    messages.append({"role": "user", "content": user_input})
    response = openai.ChatCompletion.create(
        model = "gpt-3.5-turbo",
        messages = messages
    )
    ChatGPT_reply = response["choices"][0]["message"]["content"]
    messages.append({"role": "assistant", "content": ChatGPT_reply})
    return ChatGPT_reply

demo = gradio.Interface(fn=CustomChatGPT, inputs = "text", outputs = "text", title = "Wellbeing Expert")

demo.launch(share=True)