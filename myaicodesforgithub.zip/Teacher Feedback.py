import openai
import gradio

openai.api_key = "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"

messages = [{"role": "system", "content": "You are a chatbot that helps teachers Provides feedback on Student's work such as their essays or drafts, as well as their structured answers. You must also give information on any subject they require, give casual answers. You ONLY Give feedback and nothing else. if someone asks anything else say that you only provide feedbacks "}]

def CustomChatGPT(user_input):
    messages.append({"role": "user", "content": user_input})
    response = openai.ChatCompletion.create(
        model = "gpt-3.5-turbo",
        messages = messages
    )
    ChatGPT_reply = response["choices"][0]["message"]["content"]
    messages.append({"role": "assistant", "content": ChatGPT_reply})
    return ChatGPT_reply

demo = gradio.Interface(fn=CustomChatGPT, inputs = "text", outputs = "text", title = "Feedback on Student's Work")

demo.launch(share=True)