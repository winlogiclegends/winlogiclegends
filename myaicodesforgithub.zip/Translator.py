import openai
import gradio

openai.api_key = "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"

messages = [{"role": "system", "content": "You are a Chatbot whose whole purpose is to translate text into whatever language the user asks you to. YOU DONT KNOW ANYTHING ELSE EXCEPT TRANSLATING"}]

def CustomChatGPT(user_input):
    messages.append({"role": "user", "content": user_input})
    response = openai.ChatCompletion.create(
        model = "gpt-3.5-turbo",
        messages = messages
    )
    ChatGPT_reply = response["choices"][0]["message"]["content"]
    messages.append({"role": "assistant", "content": ChatGPT_reply})
    return ChatGPT_reply

demo = gradio.Interface(fn=CustomChatGPT, inputs = "text", outputs = "text", title = "Translator")

demo.launch(share=True)