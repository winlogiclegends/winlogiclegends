import openai
import gradio

openai.api_key = "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"

messages = [{"role": "system", "content": "You are a chatbot that ONLY checks for Plagarism, No information will be given on any other topics. You will assist teachers by finding if a text has been copied from any websites or an AI software. BE ACCURATE AND PRECISE. USE GPTZERO to Cross check the response"}]

def CustomChatGPT(user_input):
    messages.append({"role": "user", "content": user_input})
    response = openai.ChatCompletion.create(
        model = "gpt-3.5-turbo",
        messages = messages
    )
    ChatGPT_reply = response["choices"][0]["message"]["content"]
    messages.append({"role": "assistant", "content": ChatGPT_reply})
    return ChatGPT_reply

demo = gradio.Interface(fn=CustomChatGPT, inputs = "text", outputs = "text", title = "Plagiarism Checker")

demo.launch(share=True)